package org.example.tool;

import java.util.*;
import java.util.stream.Collectors;

public class NumbersCollection {

    public static Map<String, Integer> mapRomanArabic;
    public static Set<String> setArabic;
    static {
        mapRomanArabic = new HashMap<>();
        mapRomanArabic.put("I", 1);
        mapRomanArabic.put("II", 2);
        mapRomanArabic.put("III", 3);
        mapRomanArabic.put("IV", 4);
        mapRomanArabic.put("V", 5);
        mapRomanArabic.put("VI", 6);
        mapRomanArabic.put("VII", 7);
        mapRomanArabic.put("VIII", 8);
        mapRomanArabic.put("IX", 9);
        mapRomanArabic.put("X", 10);
        setArabic = mapRomanArabic.values()
                .stream().map(String::valueOf).collect(Collectors.toCollection(HashSet::new));
    }

    public static boolean isNumber(String number) {
        return mapRomanArabic.keySet().contains(number) || setArabic.contains(number);
    }

    public static boolean isRoman(String number){
        return mapRomanArabic.keySet().contains(number);
    }

}
