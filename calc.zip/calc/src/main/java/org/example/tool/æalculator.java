package org.example.tool;

import org.example.exception.NoFoundArithmeticOperation;
import org.example.parser.Operation;

public class Сalculator {

    public int result(int firstNumber, int secondNumber, Operation operation) throws NoFoundArithmeticOperation {

        switch (operation) {
            case PLUS:
                return firstNumber + secondNumber;
            case MINUS:
                return  firstNumber - secondNumber;
            case MULTI:
                return firstNumber * secondNumber;
            case DIVISION:
                try {
                    return firstNumber / secondNumber;
                } catch(ArithmeticException e) {
                    System.out.println("На ноль делить нельзя!");
                }
            default:
                throw new NoFoundArithmeticOperation("Не найдена арифметическая операция");
        }

    }




}
