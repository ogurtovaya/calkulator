package org.example;

import com.sun.media.sound.InvalidDataException;
import org.example.tool.Сalculator;
import org.example.exception.NoFoundArithmeticOperation;
import org.example.parser.Operation;
import org.example.parser.Parser;
import org.example.reader.IReader;
import org.example.reader.Reader;


public class App {
    public static void main( String[] args ) throws NoFoundArithmeticOperation, InvalidDataException {

        Сalculator calculation = new Сalculator();

        System.out.println("Введите данные: ");
        IReader reader = new Reader();

        Parser parser = new Parser(reader);
        parser.parsedConsoleLine();

        System.out.println(calculation.result(parser.getFistNumber(), parser.getSecondNumber(), parser.getOperation()));
        //System.out.println(parser.getFistNumber());
        //System.out.println(parser.getSecondNumber());


        //System.out.println(parser.getOperation().toString());
    }
}
