package org.example.reader;

public interface IReader {

     String read();

}
