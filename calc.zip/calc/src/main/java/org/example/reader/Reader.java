package org.example.reader;

import org.example.reader.IReader;

import java.util.Scanner;

public class Reader implements IReader {

    private Scanner in = new Scanner(System.in);

    @Override
    public String read() {
        return in.nextLine();
    }

}
