package org.example.parser;

import org.example.exception.NoFoundArithmeticOperation;

public enum  Operation {
    PLUS("+"), MINUS("-"), MULTI("*"), DIVISION("/");

    private String operation;

    Operation(String operation){
        this.operation = operation;
    }

    public String getOperation(){ return operation;}

    public static Operation factory(String symbol) throws NoFoundArithmeticOperation {
        switch (symbol){
            case "+": return PLUS;
            case "-": return MINUS;
            case "*": return MULTI;
            case "/": return DIVISION;
            default: throw new NoFoundArithmeticOperation("Не найдена арифметическая операция");
        }
    }

}
