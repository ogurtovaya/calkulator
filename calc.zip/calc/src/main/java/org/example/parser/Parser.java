package org.example.parser;

import com.sun.media.sound.InvalidDataException;
import org.example.exception.NoFoundArithmeticOperation;
import org.example.reader.IReader;
import org.example.tool.NumbersCollection;

public class Parser {

    private int fistNumber;
    private int secondNumber;
    private Operation operation;
    private String consoleLine;

    public Parser(String consoleLine){
        this.consoleLine = consoleLine;
    }
    public Parser(IReader consoleLine){
        this.consoleLine = consoleLine.read();
    }

    public String[] parsedConsoleLine() throws NoFoundArithmeticOperation, InvalidDataException {
        String[] parsedValue = consoleLine.split(" ");

        if(!NumbersCollection.isNumber(parsedValue[0]) || !NumbersCollection.isNumber(parsedValue[2]))
            throw new InvalidDataException("Некорректные данные");

        if (Parser.checkPairRomeWithArabNumberInvalid(parsedValue[0], parsedValue[2])){
            throw new ArithmeticException("Выполнять арифметическую операцию между арабскими и римскими числами нельзя");
        }

        if (NumbersCollection.isRoman(parsedValue[0]) && NumbersCollection.isRoman(parsedValue[2])) {
            setFistNumber(NumbersCollection.mapRomanArabic.get(parsedValue[0]));
            setSecondNumber(NumbersCollection.mapRomanArabic.get(parsedValue[2]));
        } else {
            setFistNumber(Integer.parseInt(parsedValue[0]));
            setSecondNumber(Integer.parseInt(parsedValue[2]));
        }

        setOperation(Operation.factory(parsedValue[1]));

        return parsedValue;
    }

    protected static boolean checkPairRomeWithArabNumberInvalid(String firstNumber, String secondNumber){
        return NumbersCollection.mapRomanArabic.containsKey(firstNumber) &&
        NumbersCollection.setArabic.contains(secondNumber) ||
                NumbersCollection.setArabic.contains(firstNumber) &&
                        NumbersCollection.mapRomanArabic.containsKey(secondNumber);
    }

    public int getFistNumber() {
        return fistNumber;
    }

    public void setFistNumber(int fistNumber) {
        this.fistNumber = fistNumber;
    }

    public int getSecondNumber() {
        return secondNumber;
    }

    public void setSecondNumber(int secondNumber) {
        this.secondNumber = secondNumber;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }
}
