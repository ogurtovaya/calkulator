package org.example.exception;

public class NoFoundArithmeticOperation extends Throwable {
    public NoFoundArithmeticOperation(String message) {
    }
}
