package org.example.parser;

import junit.framework.TestCase;
import org.example.exception.NoFoundArithmeticOperation;
import org.junit.Assert;
import org.junit.Test;


public class OperationTest extends TestCase {

    @Test
    public void testFactoryPlus() throws NoFoundArithmeticOperation {
        Assert.assertEquals(Operation.PLUS, Operation.factory("+"));
    }

    @Test
    public void testFactoryMinus() throws NoFoundArithmeticOperation {
        Assert.assertEquals(Operation.MINUS, Operation.factory("-"));
    }

    @Test
    public void testFactoryMultyStar() throws NoFoundArithmeticOperation {
        Assert.assertEquals(Operation.MULTI, Operation.factory("*"));
    }

    @Test
    public void testFactoryDivision() throws NoFoundArithmeticOperation {
        Assert.assertEquals(Operation.DIVISION, Operation.factory("/"));
    }

    @Test(expected = NoFoundArithmeticOperation.class)
    public void testFactoryException() throws NoFoundArithmeticOperation {
        Assert.assertEquals(Operation.DIVISION, Operation.factory("8/"));
    }
}