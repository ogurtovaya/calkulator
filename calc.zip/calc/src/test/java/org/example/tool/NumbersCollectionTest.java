package org.example.tool;

import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class NumbersCollectionTest extends TestCase {

    @Test
    public void testIsNotNumberTrue() {
        Assert.assertTrue(NumbersCollection.isNumber("1"));
        Assert.assertTrue(NumbersCollection.isNumber("I"));
        Assert.assertTrue(NumbersCollection.isNumber("5"));
        Assert.assertTrue(NumbersCollection.isNumber("V"));
    }

    @Test
    public void testInvalidFalse(){
        Assert.assertFalse(NumbersCollection.isNumber("e"));
        Assert.assertFalse(NumbersCollection.isNumber("||"));
        Assert.assertFalse(NumbersCollection.isNumber("O"));
    }

}